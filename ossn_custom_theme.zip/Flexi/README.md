# Flexi 2.0

* Fixed for OSSN 6.0

# Flexi 1.5

* Issue when trying to view a post while not being logged in #9
* Bug Report: Components overlapping #8
* Sanitizing of latest friends widget #6
* Duplicate tooltips in opened left menu #5

# Flexi 1.3
1. very limited usability on screen widths from 767px - 1141px #7
